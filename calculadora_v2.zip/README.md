# 🧮 Calculadora v2.0

Projeto desenvolvido como parte de uma atividade prática de programação em Python, com o objetivo de **refatorar e otimizar uma calculadora** através do uso de **funções**, **estruturas condicionais** e **laços de repetição**.

---

## 📘 Contextualização

Após o lançamento da primeira versão da calculadora, esta segunda versão (v2) foi criada para melhorar o código, tornando-o mais modular e reutilizável.  
A aplicação permite realizar operações matemáticas básicas — **adição, subtração, multiplicação e divisão** — de forma interativa via terminal.

---

## 🧠 Conceitos abordados

- Estruturas de repetição (`while`)
- Estruturas condicionais (`if`, `elif`, `else`)
- Criação e utilização de funções em Python
- Manipulação de entrada e saída de dados (`input` e `print`)
- Tratamento de erros com `try/except`

---

## ⚙️ Requisitos

- **Python 3.x** instalado no sistema operacional  
- **VS Code** (ou outro editor de sua preferência)

---

## 🚀 Como executar o projeto

1. Clone este repositório:
   ```bash
   git clone https://github.com/Y4nnx1/calculadora_v2.git
   ```
2. Acesse a pasta do projeto:
   ```bash
   cd calculadora_v2
   ```
3. Execute o script:
   ```bash
   python calculadora_v2.py
   ```

---

## 🧩 Exemplo de uso

```
Digite o primeiro número: 10  
Digite o segundo número: 5  
Digite a operação desejada (+, -, *, / ou nome): *  
Resultado da operação: 50.0  
Deseja continuar? (S/N): s  

Digite o primeiro número: 10  
Digite o segundo número: 0  
Digite a operação desejada (+, -, *, / ou nome): /  
Resultado da operação: Não foi possível realizar a divisão por 0  
Deseja continuar? (S/N): n  

Programa encerrado. Até a próxima!
```

---

## 🗂️ Estrutura do projeto

```
calculadora_v2/
│
├── calculadora_v2.py   # Código principal da aplicação
└── README.md            # Documentação do projeto
```

---

## 📤 Entrega

- O repositório deve ser **público no GitHub**.  
- Envie o link do repositório ao tutor através da **Sala de Aula Virtual (SAVA)** → aba **Trabalhos**.  
- Certifique-se de entregar **dentro do prazo estipulado**.

---

## ✍️ Autor

**YAN GABRIEL SILVA SANTOS**  
💻 Usuário GitHub: [Y4nnx1](https://github.com/Y4nnx1)  
📅 Data de entrega: 13/11/2025  
