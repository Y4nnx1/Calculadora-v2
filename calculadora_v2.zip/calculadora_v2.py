# -----------------------------------------------------------
# Calculadora v2.0 - Trabalho Prático
# Autor: YAN GABRIEL SILVA SANTOS
# Data: 13/11/2025
# -----------------------------------------------------------

saida = ''

def adicao(a, b):
    return a + b

def subtracao(a, b):
    return a - b

def multiplicacao(a, b):
    return a * b

def divisao(a, b):
    if b == 0:
        return "Não foi possível realizar a divisão por 0"
    else:
        return a / b

def calculadora(num1, num2, operacao):
    if operacao == '+' or operacao.lower() == 'adicao':
        resultado = adicao(num1, num2)
    elif operacao == '-' or operacao.lower() == 'subtracao':
        resultado = subtracao(num1, num2)
    elif operacao == '*' or operacao.lower() == 'multiplicacao':
        resultado = multiplicacao(num1, num2)
    elif operacao == '/' or operacao.lower() == 'divisao':
        resultado = divisao(num1, num2)
    else:
        resultado = "Operação inválida!"
    
    return resultado

while saida.lower() != 'n':
    try:
        numero1 = float(input("Digite o primeiro número: "))
        numero2 = float(input("Digite o segundo número: "))
        operacao = input("Digite a operação desejada (+, -, *, / ou nome): ")

        resultado = calculadora(numero1, numero2, operacao)
        print(f"Resultado da operação: {resultado}")

    except ValueError:
        print("Erro: Certifique-se de digitar números válidos.")

    saida = input("Deseja continuar? (S/N): ").strip().lower()
    while saida not in ['s', 'n']:
        saida = input("Entrada inválida. Deseja continuar? (S/N): ").strip().lower()

print("Programa encerrado. Até a próxima!")
